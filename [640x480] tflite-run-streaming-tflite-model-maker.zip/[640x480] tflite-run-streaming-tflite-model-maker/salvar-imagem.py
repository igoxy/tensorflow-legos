import urllib.request
import cv2
import numpy as np

contador = 0

while True:
    imgResp = urllib.request.urlopen('http://221.1.1.113/capture')
    imgNp = np.array(bytearray(imgResp.read()), dtype=np.uint8)
    frame = cv2.imdecode(imgNp, -1)
    cv2.imshow('frame', frame)
    largura = frame.shape[1]
    altura = frame.shape[0]
    #print(str(largura) + 'x' + str(altura))
    key = cv2.waitKey(1)
    if key == ord('s'):
        contador += 1
        cv2.imwrite(f'imagens/lego{contador}.png', frame)
        print(f'imagem {contador} salva!')
    if key == ord('q'):
        break
cv2.destroyAllWindows
print('fim')