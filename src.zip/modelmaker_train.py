# -*- coding: utf-8 -*-

# --- imports ---
import argparse
from training import training
# --- fim imports ---

# --- Arquiteturas ---
MODEL_ARCS = {
    'lite0': 'efficientdet_lite0',
    'lite1': 'efficientdet_lite1',
    'lite2': 'efficientdet_lite2',
    'lite3': 'efficientdet_lite3',
    'lite4': 'efficientdet_lite4'
}

# --- argparse script ---
DEFAULT_ARGS = {
        '--dir_train': [str],
        '--dir_val': [str], 
        '--class': [str], 
        '--epochs': [int, '?', 20], 
        '--dir_export': [str, '?', '.'], 
        '--model': [str, '?', 'lite0'],
        '--batch_size': [int, '?', 4]
        }

get_args = {
        'dir_train': None,
        'dir_val': None, 
        'class': None, 
        'epochs': None,
        'dir_export': None,
        'model': None,
        'batch_size': None
        }

parser = argparse.ArgumentParser(description='Treina o modelo de detecção de objetos para Tensorflow Lite utilizando o Model Maker.')

for arg, options in DEFAULT_ARGS.items():
    if (len(options) > 1):
        parser.add_argument(arg, type=options[0], nargs=options[1], default=options[2])
    else:
        parser.add_argument(arg, type=options[0], required=True)

args = parser.parse_args().__dict__ # Converte para dicionário

for key, value in args.items():
    try:
        if key == 'class':
            value = value.split(',')
        elif key == 'model':
            value = MODEL_ARCS[value]
        get_args[key] = value
    except Exception as ex:
        print(f'Os parâmetros informados não atendem ao padrão. Detalhes: {ex}')
# --- fim argparse script ---

# --- MAIN ---
if __name__ == '__main__':
    training(get_args)  # Chama a função para o treinamento, avaliação e exportação do modelo
    print('\n\n --- Fim ---')
