# -*- coding: utf-8 -*-

# --- imports, asserts e logs ---
from tflite_model_maker import model_spec
from tflite_model_maker import object_detector

import tensorflow as tf

from absl import logging

assert tf.__version__.startswith('2')
tf.get_logger().setLevel('ERROR')
logging.set_verbosity(logging.ERROR)

# --- fim imports, asserts e logs ---

def training(args: dict) -> bool:
    # Carregando os dados do dataset
    train_data = object_detector.DataLoader.from_pascal_voc(
        args['dir_train'],
        args['dir_train'],
        args['class']
    )

    val_data = object_detector.DataLoader.from_pascal_voc(
        args['dir_val'],
        args['dir_val'],
        args['class']
    )

    # Arquitetura do modelo
    model_arc = model_spec.get(args['model'])

    # Treinamento
    print('\n-- Treinando o modelo --')
    model = object_detector.create(train_data, model_spec=model_arc, batch_size=args['batch_size'], train_whole_model=True, epochs=args['epochs'], validation_data=val_data)

    # Avaliando o modelo gerado
    print('\n-- Avaliação do modelo --')
    evaluate = model.evaluate(val_data)
    print(evaluate)

    # Exportando o modelo
    model.export(export_dir=args['dir_export'], tflite_filename='model.tflite')
    print(f'\nModelo exportado no diretório: {args["dir_export"]}')

    # Avaliando o modelo em TFLite
    print('\n-- Avaliando o modelo em TFLite --')
    evaluate_tflite = model.evaluate_tflite(f'{args["dir_export"]}/model.tflite', val_data)
    print(evaluate_tflite)